package com.aadhar.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.aadhar.service.AaadharDTO;
import com.aadhar.service.AadharService;
import com.aadhar.service.AadharServiceImplService;

public class AaadharWebConsumerController extends HttpServlet {

	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String aadharNo = null;
		RequestDispatcher rd = null;

		aadharNo = req.getParameter("aadharNo");
		Long ano = Long.parseLong(aadharNo);
		AadharServiceImplService service = new AadharServiceImplService();
		AadharService aadharService = service.getAadharServiceImplPort();
		List<AaadharDTO> listDto = aadharService.findByAadhar(ano);
		req.setAttribute("aadharInfo", listDto);
		rd = req.getRequestDispatcher("/aadharinfo.jsp");
		rd.forward(req, resp);
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		doGet(req, resp);
	}

}
