
package com.aadhar.service;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.aadhar.service package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _FindByAadharResponse_QNAME = new QName("http://service.aadhar.com/", "findByAadharResponse");
    private final static QName _InsertResponse_QNAME = new QName("http://service.aadhar.com/", "insertResponse");
    private final static QName _FindByAadhar_QNAME = new QName("http://service.aadhar.com/", "findByAadhar");
    private final static QName _Insert_QNAME = new QName("http://service.aadhar.com/", "insert");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.aadhar.service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Insert }
     * 
     */
    public Insert createInsert() {
        return new Insert();
    }

    /**
     * Create an instance of {@link FindByAadhar }
     * 
     */
    public FindByAadhar createFindByAadhar() {
        return new FindByAadhar();
    }

    /**
     * Create an instance of {@link InsertResponse }
     * 
     */
    public InsertResponse createInsertResponse() {
        return new InsertResponse();
    }

    /**
     * Create an instance of {@link FindByAadharResponse }
     * 
     */
    public FindByAadharResponse createFindByAadharResponse() {
        return new FindByAadharResponse();
    }

    /**
     * Create an instance of {@link AaadharDTO }
     * 
     */
    public AaadharDTO createAaadharDTO() {
        return new AaadharDTO();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindByAadharResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.aadhar.com/", name = "findByAadharResponse")
    public JAXBElement<FindByAadharResponse> createFindByAadharResponse(FindByAadharResponse value) {
        return new JAXBElement<FindByAadharResponse>(_FindByAadharResponse_QNAME, FindByAadharResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InsertResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.aadhar.com/", name = "insertResponse")
    public JAXBElement<InsertResponse> createInsertResponse(InsertResponse value) {
        return new JAXBElement<InsertResponse>(_InsertResponse_QNAME, InsertResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindByAadhar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.aadhar.com/", name = "findByAadhar")
    public JAXBElement<FindByAadhar> createFindByAadhar(FindByAadhar value) {
        return new JAXBElement<FindByAadhar>(_FindByAadhar_QNAME, FindByAadhar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Insert }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://service.aadhar.com/", name = "insert")
    public JAXBElement<Insert> createInsert(Insert value) {
        return new JAXBElement<Insert>(_Insert_QNAME, Insert.class, null, value);
    }

}
